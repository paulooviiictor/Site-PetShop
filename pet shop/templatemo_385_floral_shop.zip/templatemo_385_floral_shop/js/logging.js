$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+803539+'&oi='+396+'&ot=1&&url='+window.location, function(json){})    

});